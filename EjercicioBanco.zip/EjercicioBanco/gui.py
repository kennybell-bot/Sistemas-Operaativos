from tkinter import *

root = Tk()

label = Label(root, text="Banco")
label.grid(row=0, column=0)

label2 = Label(root, text="Cajero:")
label2.grid(row=1, column=0)

label3 = Label(root, text="Ingrese el numero de transacciones")
label3.grid(row=2, column=0)

ingreso = Entry(root)
ingreso.grid(row=3, column=0)

mybutton = Button(root, text="Encolar")
mybutton.grid(row=4, column=0)

root.mainloop()